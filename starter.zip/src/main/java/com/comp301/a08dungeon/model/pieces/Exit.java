package com.comp301.a08dungeon.model.pieces;

public class Exit extends APiece {

  public Exit() {}
}
