package com.comp301.a08dungeon.model.pieces;

public class Enemy extends APiece implements MovablePiece {

  public Enemy() {}

  public CollisionResult collide(Piece other) {
    return null;
  }
}
