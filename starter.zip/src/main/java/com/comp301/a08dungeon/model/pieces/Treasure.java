package com.comp301.a08dungeon.model.pieces;

public class Treasure extends APiece {

  public Treasure() {}

  public int getValue() {
    return -1;
  }
}
