package com.comp301.a08dungeon.model;

public interface Observer {
  void update();
}
