package com.comp301.a08dungeon.model.pieces;

public class Hero extends APiece implements MovablePiece {
  public Hero() {}

  public CollisionResult collide(Piece other) {
    return null;
  }
}
